# Som da avenida do Loterias 24 Horas: o carro acelera e some, volta pela esquerda, freia,
# o braço saca o bilhete (plim), buzina bi-bi e os números acendem. Mesmos tempos do l24_avenida.py.
import sys, numpy as np, scipy.signal as ss, wave
SR=44100; DUR=9.0; N=int(SR*DUR); t=np.arange(N)/SR; rng=np.random.default_rng(6)
def norm(x): m=np.max(np.abs(x)); return x/m if m>0 else x
def lp(x,f): b,a=ss.butter(2,f/(SR/2)); return ss.lfilter(b,a,x)
def bp(x,lo,hi): b,a=ss.butter(2,[lo/(SR/2),hi/(SR/2)],"band"); return ss.lfilter(b,a,x)
# motor: sai acelerando (0–1.6), some (1.6–2.1), volta chegando (2.1–4.2), freia e fica em marcha lenta
f=np.interp(t,[0,.25,1.0,1.6,2.1,2.3,3.0,3.8,4.2,9.0],[200,300,330,345,250,235,150,95,80,78])
a=np.interp(t,[0,.12,.9,1.5,1.7,2.1,2.4,3.2,4.0,4.4,9.0],[0.0,.85,.7,.25,0.0,0.0,.7,.62,.3,.18,.16])
f=f*(1+.012*np.sin(2*np.pi*11*t))
ph=2*np.pi*np.cumsum(f)/SR
eng=sum(np.sin(k*ph+k)/k**.9 for k in range(1,14))+.6*np.sin(.5*ph)
eng=norm(lp(eng,1900))*(1+.25*np.sin(.5*ph))
vento=norm(bp(rng.standard_normal(N),500,3000))*np.interp(t,[0,.3,1.2,1.7,2.1,2.6,3.6,4.3,9.0],[0,.55,.45,.1,0,.1,.4,.05,0])
mix=.5*norm(eng)*a+.16*vento
def poe(sig,t0,g):
    i=int(t0*SR); j=min(N,i+len(sig)); mix[i:j]+=g*sig[:j-i]
# freada curta, quando encosta na lotérica
n=int(.32*SR); tt=np.arange(n)/SR
poe(norm(bp(rng.standard_normal(n),1500,4200))*np.sin(np.pi*tt/.32)**2+.3*np.sin(2*np.pi*(1750-500*tt)*tt)*np.sin(np.pi*tt/.32)**2,3.9,.14)
# plim do bilhete
def sino(fr,d=.7,tau=.2):
    n=int(d*SR); tt=np.arange(n)/SR
    return (np.sin(2*np.pi*fr*tt)+.4*np.sin(2*np.pi*2*fr*tt)*np.exp(-tt/(tau*.5)))*np.exp(-tt/tau)*np.minimum(1,tt/.003)
for k,fr in enumerate([1318.5,1661.2,1975.5,2637]): poe(sino(fr),4.45+.1*k,.22)
# buzina bi-bi
def buzina(d=.24):
    n=int(d*SR); tt=np.arange(n)/SR; s=np.zeros(n)
    for fr in (415,523):
        for k in (1,2,3,4,5,6): s+=np.sin(2*np.pi*fr*k*tt)/k
    return norm(lp(s,3200))*np.minimum(1,tt/.008)*np.clip((d-tt)/.03,0,1)
poe(buzina(),5.05,.5); poe(buzina(.3),5.4,.5)
# plins dos números acendendo
for k,t0 in enumerate([6.0,6.35,6.7]): poe(sino(2637,d=.3,tau=.07),t0,.1)
mix*=np.clip(t/.01,0,1)*np.clip((DUR-t)/.12,0,1)
mix=.9*mix/np.max(np.abs(mix))
with wave.open(sys.argv[1],"wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix*32767).astype("<i2").tobytes())
print("som ok")
