# Cena da avenida do Loterias 24 Horas (entra no lugar do mascote salsicha).
# Parado: o conversível vermelho fica estacionado na frente da lotérica com o bilhete do PALPITE DO DIA erguido.
# Show (9,0 s): acelera e some à direita, volta pela esquerda, freia, saca o bilhete, buzina e os números acendem.
# Os tempos batem com o l24_som_avenida.py. O bilhete usa as classes .sx-bola e .sx-pd, que o JS do palpite preenche.
import math

T = 9.0
def P(t): return "%.2f%%" % max(0.0, min(100.0, t / T * 100))
def kf(nome, q):
    return "@keyframes %s{%s}" % (nome, "".join("%s{%s%s}" % (P(x[0]), x[1], (";animation-timing-function:" + x[2]) if len(x) > 2 else "") for x in q))
FREIA, ACELERA = "cubic-bezier(.15,.7,.35,1)", "cubic-bezier(.6,0,.9,.4)"

css = ["""
.sx text{font-family:Outfit,Inter,system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;font-weight:800}
.sx .emo{font-family:"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",system-ui,sans-serif;font-weight:400}
.av-carro{transform:translateX(150px)}
.av-roda{transform-box:fill-box;transform-origin:50% 50%}
.av-corpo{transform-origin:150px 100px}
.av-braco{transform-origin:150px 52px}
.sx-bola{transform-box:fill-box;transform-origin:50% 50%}
.av-br,.av-bibi,.av-vento,.av-fum{opacity:0}
.sx-dica{transform-box:fill-box;transform-origin:50% 50%;animation:sx-dica 1.5s ease-in-out infinite alternate}
@keyframes sx-dica{from{transform:scale(1)}to{transform:scale(1.06)}}
.sx-led1{animation:sx-led1 8s steps(1,end) infinite}
.sx-led2{animation:sx-led2 8s steps(1,end) infinite}
@keyframes sx-led1{0%{opacity:1}50%{opacity:0}100%{opacity:1}}
@keyframes sx-led2{0%{opacity:0}50%{opacity:1}100%{opacity:0}}
@media (prefers-reduced-motion:reduce){.sx-led1,.sx-led2,.sx-dica{animation:none}.sx-led2{opacity:0}}
"""]
reg = []
def anima(sel, nome, q):
    css.append(kf(nome, q)); reg.append(".sx.show %s{animation:%s %ss linear both}" % (sel, nome, T))

X = lambda x, o=1: "transform:translateX(%spx);opacity:%s" % (x, o)
R = lambda a: "transform:rotate(%sdeg)" % a
O = lambda o: "opacity:%s" % o
S = lambda s: "transform:scale(%s)" % s

# ---- carro: sai acelerando, some, volta pela esquerda e freia na lotérica ----
anima(".av-carro", "av-carro", [(0, X(150), ACELERA), (1.6, X(660)), (1.65, X(660, 0)), (1.9, X(-340, 0)),
                                (2.05, X(-340), FREIA), (4.2, X(150)), (T, X(150))])
anima(".av-roda", "av-roda", [(0, R(0), ACELERA), (1.6, R(1440)), (2.05, R(1440), FREIA), (4.2, R(2880)), (T, R(2880))])
anima(".av-corpo", "av-corpo", [(0, R(0)), (.25, R(-2.2)), (1.0, R(0)), (2.05, R(0)), (3.7, R(0)), (4.1, R(1.8)),
                                (4.5, R(0)), (T, R(0))])
anima(".av-vento", "av-vento", [(0, O(.6)), (.4, O(1)), (1.5, O(1)), (1.62, O(0)), (2.1, O(0)), (2.4, O(.9)),
                                (3.7, O(.5)), (4.2, O(0)), (T, O(0))])
anima(".av-fum", "av-fum", [(0, O(0)), (.1, O(.9)), (.9, O(.5)), (1.5, O(0)), (T, O(0))])

# ---- braço com o bilhete do palpite ----
H = "transform:rotate(70deg) scale(.15);opacity:0"
V = lambda a, s=1: "transform:rotate(%sdeg) scale(%s);opacity:1" % (a, s)
anima(".av-braco", "av-braco", [(0, H), (4.35, H), (4.7, V(-6, 1.08)), (4.95, V(0)), (5.35, V(-7)), (5.75, V(4)),
                                (6.15, V(-7)), (6.55, V(4)), (6.95, V(0)), (T, V(0))])

# ---- números acendem nos plins ----
anima(".sx-bola", "av-bola", [(0, S(1)), (5.9, S(1)), (6.0, S(1.16)), (6.2, S(1)), (6.35, S(1.16)), (6.55, S(1)),
                              (6.7, S(1.16)), (6.9, S(1)), (T, S(1))])

# ---- estrelinhas piscando ----
q = [(0, O(0)), (4.9, O(0))]; t, on = 4.9, True
while t < 7.3:
    t += .3; q.append((round(t, 2), O(1) if on else O(.25))); on = not on
q += [(7.6, O(0)), (T, O(0))]
anima(".av-br", "av-br", q)
anima(".av-bibi", "av-bibi", [(0, O(0)), (4.98, O(0)), (5.05, O(1)), (5.8, O(1)), (6.0, O(0)), (T, O(0))])
anima(".sx-dica", "av-dica", [(0, O(1)), (.15, O(0)), (8.6, O(0)), (T, O(1))])

css += reg
css.append("@media (prefers-reduced-motion:reduce){.sx.show .av-carro,.sx.show .av-roda,.sx.show .av-corpo,"
           ".sx.show .av-braco,.sx.show .sx-bola,.sx.show .av-vento,.sx.show .av-fum{animation:none}}")

def estrela(cx, cy, Rr=10, r=4.5):
    pts = []
    for k in range(10):
        a = math.radians(-90 + 36 * k); rr = Rr if k % 2 == 0 else r
        pts.append("%.1f %.1f" % (cx + rr * math.cos(a), cy + rr * math.sin(a)))
    return '<path class="av-br" d="M' + "L".join(pts) + 'Z" fill="#F5C842" stroke="#C99A12" stroke-width="1.5"/>'

def roda(cx):
    return ('<g class="av-roda"><circle cx="%d" cy="100" r="20" fill="#151515"/><circle cx="%d" cy="100" r="11" fill="#C9CED6"/>'
            '<path d="M%d 89V111M%d 100H%d" stroke="#7B828C" stroke-width="3"/></g>') % (cx, cx, cx, cx - 11, cx + 11)

# ---- bilhete do palpite do dia ----
PAD = [7, 13, 24, 33, 41, 58]
BX, BY, BW, BH = 28, -232, 260, 222
bolas = []
for i, n in enumerate(PAD):
    cx = 93 + 65 * (i % 3); cy = -156 + 64 * (i // 3)
    bolas.append('<g class="sx-bola"><circle cx="%d" cy="%d" r="27" fill="#0E7A3E"/>'
                 '<text x="%d" y="%d" font-size="27" fill="#fff" text-anchor="middle">%02d</text></g>' % (cx, cy, cx, cy + 10, n))
bilhete = ('<g transform="rotate(-5 158 -121)">'
  '<rect x="%d" y="%d" width="%d" height="%d" rx="10" fill="#fff" stroke="#0B5F31" stroke-width="4"/>' % (BX, BY, BW, BH) +
  '<path d="M28 -222a10 10 0 0 1 10-10h240a10 10 0 0 1 10 10v30H28z" fill="#0E7A3E"/>'
  '<text x="158" y="-200" font-size="21" fill="#fff" text-anchor="middle">LOTERIAS 24 HORAS</text>'
  + "".join(bolas) +
  '<text class="sx-pd" x="158" y="-32" font-size="16" fill="#0B3D24" text-anchor="middle">PALPITE DO DIA</text>'
  '</g>')

carro = ('<g transform="translate(0 180)"><g class="av-carro">'
 '<path class="av-vento" d="M-78 58H-16M-104 76H-30M-66 92H-12" stroke="#fff" stroke-width="5" stroke-linecap="round"/>'
 '<g class="av-fum" fill="#D5D9DF"><circle cx="-4" cy="90" r="9"/><circle cx="-22" cy="82" r="12"/><circle cx="-44" cy="74" r="15"/></g>'
 '<g class="av-corpo">'
 '<path d="M22 66V44" stroke="#7A0D0D" stroke-width="5"/><path d="M2 38H46L42 47H6Z" fill="#9E1515"/>'
 '<path d="M8 92V68C8 62 14 58 24 58H186L262 68C284 71 296 78 296 86V92C296 97 292 100 286 100H18C12 100 8 97 8 92Z" fill="#D21F1F" stroke="#7A0D0D" stroke-width="3"/>'
 '<path d="M186 58L170 32L158 58Z" fill="#9CC3E8" opacity=".75"/><path d="M186 58L170 32" stroke="#23313F" stroke-width="5" stroke-linecap="round"/>'
 '<rect x="112" y="38" width="14" height="22" rx="5" fill="#3B2414"/>'
 '<path d="M132 59c0-11 8-15 16-15s14 4 14 15z" fill="#fff"/>'
 '<circle cx="150" cy="31" r="11" fill="#E0A77A"/><path d="M139 30c-1-12 17-15 22-5c-8-3-14-1-16 6z" fill="#3B2414"/>'
 '<rect x="150" y="27" width="13" height="5" rx="2" fill="#111"/><path d="M152 37q4 3 8 0" fill="none" stroke="#7A3B1E" stroke-width="2" stroke-linecap="round"/>'
 '<path d="M120 61V96M204 63V96" stroke="#7A0D0D" stroke-width="2"/><path d="M20 84H288" stroke="#F5C842" stroke-width="3" stroke-linecap="round"/>'
 '<path d="M282 76l12 5v6h-14z" fill="#FFE9A3"/><rect x="8" y="70" width="6" height="11" rx="2" fill="#FF9A9A"/>'
 + roda(66) + roda(236) +
 '<g class="av-braco">'
 '<path d="M150 52L158 2" stroke="#E0A77A" stroke-width="9" stroke-linecap="round"/>'
 + bilhete +
 '<circle cx="158" cy="2" r="7" fill="#E0A77A"/>'
 + estrela(8, -236, 13, 5.5) + estrela(306, -218, 12, 5) + estrela(312, -30, 10, 4) + estrela(10, -46, 9, 4) +
 '</g>'
 '<g class="av-bibi"><rect x="216" y="2" width="84" height="32" rx="16" fill="#fff" stroke="#14213D" stroke-width="2.5"/>'
 '<path d="M262 34l6 10 4-10z" fill="#fff" stroke="#14213D" stroke-width="2.5" stroke-linejoin="round"/>'
 '<text x="258" y="24" font-size="17" fill="#14213D" text-anchor="middle">Bi-bi!</text></g>'
 '</g></g></g>')

dica = ('<g class="sx-dica"><rect x="10" y="-188" width="152" height="38" rx="19" fill="#fff" stroke="#163A8F" stroke-width="3"/>'
        '<text class="sx-dt" x="86" y="-163" font-size="17" fill="#163A8F" text-anchor="middle">Toque aqui <tspan class="emo">🔊</tspan></text></g>')

# ---- painel de LED em cima da lotérica ----
def led(cls, linhas):
    t = []
    for i, (txt, cor, tam, y) in enumerate(linhas):
        t.append('<text x="300" y="%d" font-size="%d" fill="%s" text-anchor="middle" letter-spacing="1.5">%s</text>' % (y, tam, cor, txt))
    return '<g class="%s">%s</g>' % (cls, "".join(t))

painel = ('<g>'
 '<rect x="192" y="-104" width="15" height="148" fill="#6B7280"/><rect x="393" y="-104" width="15" height="148" fill="#6B7280"/>'
 '<rect x="186" y="36" width="27" height="10" rx="3" fill="#565C66"/><rect x="387" y="36" width="27" height="10" rx="3" fill="#565C66"/>'
 '<rect x="140" y="-194" width="320" height="100" rx="9" fill="#1A1E26" stroke="#0A0D12" stroke-width="5"/>'
 '<rect x="151" y="-185" width="298" height="74" rx="4" fill="#06080C"/>'
 + led("sx-led1", [("BOLÕES DA CAIXA", "#FFC53D", 25, -152), ("AQUI NA AVENIDA", "#4DE08A", 22, -124)])
 + led("sx-led2", [("MEGA DA VIRADA", "#FF5C5C", 25, -152), ("R$ 1 BILHÃO", "#FFC53D", 24, -124)])
 + '<rect x="151" y="-185" width="298" height="74" rx="4" fill="url(#sxled)"/>'
 '<text x="300" y="-100" font-size="12" fill="#8A93A0" text-anchor="middle" letter-spacing="2">JC LED</text>'
 '</g>')

# ---- rotatória na frente da lotérica ----
rotatoria = ('<g>'
 '<ellipse cx="300" cy="332" rx="252" ry="64" fill="none" stroke="#fff" stroke-width="4" stroke-dasharray="26 20" opacity=".85"/>'
 '<ellipse cx="300" cy="332" rx="172" ry="42" fill="#D9D2C3" stroke="#9AA3AE" stroke-width="3"/>'
 '<ellipse cx="300" cy="334" rx="156" ry="33" fill="#2E8B4F"/>'
 '<g fill="#F5C842"><circle cx="246" cy="318" r="5"/><circle cx="300" cy="312" r="5"/><circle cx="354" cy="318" r="5"/></g>'
 '<g fill="#E8667A"><circle cx="272" cy="326" r="4.5"/><circle cx="328" cy="326" r="4.5"/></g>'
 '</g>')

cena = ('<svg class="sx" viewBox="0 -200 600 530" role="img" aria-label="Cena da avenida: toque para o carro passar e sacar o bilhete com o palpite do dia" focusable="false" xmlns="http://www.w3.org/2000/svg">'
 '<style>' + "".join(css) + '</style>'
 '<defs><pattern id="sxled" width="5" height="5" patternUnits="userSpaceOnUse">'
 '<path d="M0 0H5M0 0V5" stroke="#06080C" stroke-width="1.7" opacity=".8"/></pattern></defs>'
 '<rect x="0" y="-200" width="600" height="405" fill="#E6F0FF"/><circle cx="545" cy="42" r="24" fill="#FFD766"/>'
 '<rect x="505" y="120" width="10" height="82" fill="#7A5230"/><circle cx="510" cy="104" r="34" fill="#178A47"/><circle cx="534" cy="122" r="22" fill="#1E9E55"/>'
 '<rect x="150" y="40" width="300" height="162" rx="6" fill="#163A8F"/>'
 '<rect x="160" y="50" width="280" height="42" rx="6" fill="#fff"/><text x="300" y="79" font-size="22" fill="#163A8F" text-anchor="middle">LOTÉRICA DA AVENIDA</text>'
 '<path d="M150 100H450V114H150Z" fill="#EE7B3D"/><path d="M150 114H450V120H150Z" fill="#178A47"/>'
 '<rect x="170" y="132" width="84" height="50" rx="4" fill="#DCE4F7"/><rect x="346" y="132" width="84" height="50" rx="4" fill="#DCE4F7"/>'
 '<rect x="272" y="128" width="56" height="74" rx="4" fill="#EAF0FB"/><circle cx="318" cy="166" r="3.5" fill="#163A8F"/>'
 + painel +
 '<rect x="66" y="74" width="7" height="130" fill="#6B7280"/><rect x="6" y="50" width="128" height="34" rx="6" fill="#0E7A3E"/><text x="70" y="73" font-size="15" fill="#fff" text-anchor="middle">Av. 6 de Agosto</text>'
 '<rect y="200" width="600" height="24" fill="#D9D2C3"/><rect y="222" width="600" height="6" fill="#9AA3AE"/>'
 '<rect y="228" width="600" height="102" fill="#3A3F47"/><path d="M0 300H58M542 300H600" stroke="#fff" stroke-width="5" stroke-dasharray="38 28"/>'
 + rotatoria + carro + dica + '</svg>')

open("/home/claude/scripts/l24_avenida.svg", "w", encoding="utf-8").write(cena)
print("avenida ok ·", len(cena), "bytes")
