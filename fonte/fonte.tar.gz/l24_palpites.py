# Palpite do dia do salsicha: um jogo de 6 dezenas por dia, até o último dia da Mega da Virada.
# Regras da casa: 3 pares e 3 ímpares, no máximo 2 dezenas por linha do volante, sem o 01.
# Quem já tem palpite não muda (o que já apareceu no site fica igual na planilha).
import json, secrets, datetime
ARQ = "/home/claude/loterias24horas1/dados.json"
INI, FIM = datetime.date(2026, 11, 26), datetime.date(2026, 12, 31)
r = secrets.SystemRandom()
def valido(n):
    if 1 in n or sum(x % 2 == 0 for x in n) != 3: return False
    linhas = {}
    for x in n: linhas[(x - 1) // 10] = linhas.get((x - 1) // 10, 0) + 1
    return max(linhas.values()) <= 2
d = json.load(open(ARQ, encoding="utf-8"))
pal = d.get("palpites", {})
vistos = {tuple(v) for v in pal.values()}
dia, novos = INI, 0
while dia <= FIM:
    k = dia.isoformat()
    if k not in pal:
        while True:
            n = sorted(r.sample(range(1, 61), 6))
            if valido(n) and tuple(n) not in vistos: break
        pal[k] = n; vistos.add(tuple(n)); novos += 1
    dia += datetime.timedelta(days=1)
d["palpites"] = dict(sorted(pal.items()))
def bonito(v, n=0):
    """objetos em várias linhas; cada bolão e cada palpite numa linha só"""
    pad = "  " * (n + 1)
    if isinstance(v, dict):
        itens = [f'{pad}{json.dumps(k, ensure_ascii=False)}: {bonito(x, n + 1)}' for k, x in v.items()]
        return "{\n" + ",\n".join(itens) + "\n" + "  " * n + "}"
    if isinstance(v, list) and v and all(isinstance(x, dict) for x in v):
        return "[\n" + ",\n".join(pad + json.dumps(x, ensure_ascii=False) for x in v) + "\n" + "  " * n + "]"
    return json.dumps(v, ensure_ascii=False)
open(ARQ, "w", encoding="utf-8").write(bonito(d) + "\n")
assert json.load(open(ARQ, encoding="utf-8"))["palpites"] == d["palpites"]
assert all(valido(v) for v in d["palpites"].values())
print(len(d["palpites"]), "palpites ·", novos, "novos ·", list(d["palpites"].items())[:2])
