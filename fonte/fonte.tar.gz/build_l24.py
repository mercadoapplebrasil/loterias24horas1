# Monta o Loterias 24 Horas a partir do modelo.
#   python3 build_l24.py final   -> index.html na raiz (site oficial)
#   python3 build_l24.py previa  -> novo/index.html (noindex)
# Os bolões vêm do dados.json e já saem escritos no HTML (bom pro Google e abre mais rápido);
# no navegador o script relê o dados.json, atualiza a contagem e some com o que já fechou.
import sys, os, re, json, shutil, subprocess, threading, functools, datetime
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler

REPO = "/home/claude/loterias24horas1"
SC = "/home/claude/scripts"
modo = sys.argv[1] if len(sys.argv) > 1 else "previa"
pasta = REPO if modo == "final" else REPO + "/novo"

tpl = open(SC + "/l24_template.html", encoding="utf-8").read()
subprocess.run(["python3", SC + "/l24_avenida.py"], check=True)
svg = open(SC + "/l24_avenida.svg", encoding="utf-8").read()
if not os.path.exists(REPO + "/avenida.mp3"):
    subprocess.run(["python3", SC + "/l24_som_avenida.py", "/tmp/l24_avenida.wav"], check=True)
    subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", "/tmp/l24_avenida.wav",
                    "-codec:a", "libmp3lame", "-b:a", "80k", "-ac", "1", REPO + "/avenida.mp3"], check=True)
IC_ZAP = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M17.47 14.38c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.07-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.47-1.75-1.64-2.05-.17-.3-.02-.46.13-.6.13-.14.3-.35.44-.52.15-.18.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.61-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.21 3.07c.15.2 2.1 3.2 5.08 4.49.71.31 1.27.49 1.7.63.72.23 1.37.2 1.88.12.58-.09 1.75-.72 2-1.41.25-.7.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35M12.05 21.79h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.88 9.89-9.88 2.64 0 5.12 1.03 6.99 2.9a9.82 9.82 0 0 1 2.89 6.99c0 5.45-4.44 9.88-9.88 9.88m8.41-18.3A11.81 11.81 0 0 0 12.05 0C5.5 0 .16 5.34.16 11.89c0 2.1.55 4.14 1.59 5.95L.06 24l6.31-1.65a11.88 11.88 0 0 0 5.68 1.45h.01c6.55 0 11.89-5.34 11.89-11.89 0-3.18-1.24-6.16-3.48-8.41"/></svg>'
IC_SH = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15V3M7 8l5-5 5 5M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
IC_OK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l7 3v5c0 4.5-3 8.4-7 10-4-1.6-7-5.5-7-10V6z" fill="#fff" stroke="#0E7A3E" stroke-width="2" stroke-linejoin="round"/><path d="M8.5 12l2.5 2.5 4.5-5" fill="none" stroke="#0E7A3E" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
assert "'" not in IC_ZAP and "'" not in IC_SH
CARREGANDO = '<p class="aviso-msg">Carregando os bolões…</p>'

def montar(lista, vlista, extra=None):
    dj = json.dumps(json.load(open(REPO + "/dados.json", encoding="utf-8")), ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    out = (tpl.replace("%%DADOS%%", "<script>window.L24I=" + dj + "</script>").replace("%%MASCOTE%%", svg).replace("%%IC_ZAP_JS%%", IC_ZAP).replace("%%IC_SH_JS%%", IC_SH)
              .replace("%%IC_ZAP%%", IC_ZAP).replace("%%IC_OK%%", IC_OK)
              .replace("%%ROBOTS%%", '<meta name="robots" content="noindex">\n' if modo != "final" else "")
              .replace("%%LISTA%%", lista).replace("%%VLISTA%%", vlista))
    if extra:  # faixa "Próximo" e palpite já visíveis no HTML: nada pula quando o JS liga
        out = re.sub(r'<a class="prox" id="prox".*?</a>', lambda m: extra[0], out, count=1, flags=re.S)
        out = re.sub(r'<section class="w sec palp" id="palpite".*?</section>', lambda m: extra[1], out, count=1, flags=re.S)
    assert "%%" not in out
    return out

# dados e som ficam na mesma pasta da página
if modo == "final":
    for f in ("dados.json", "avenida.mp3"):
        if not os.path.exists(REPO + "/" + f) and os.path.exists(REPO + "/novo/" + f):
            shutil.copy(REPO + "/novo/" + f, REPO + "/" + f)
dest = pasta + "/index.html"
open(dest, "w", encoding="utf-8").write(montar(CARREGANDO, ""))

# pré-render: abre a página num Chrome sem tela e guarda os cartões já montados
class Quieto(SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
srv = ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(Quieto, directory=REPO))
threading.Thread(target=srv.serve_forever, daemon=True).start()
url = f"http://127.0.0.1:{srv.server_address[1]}/" + ("" if modo == "final" else "novo/")
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
    pg = b.new_page(viewport={"width": 390, "height": 844})
    pg.goto(url, wait_until="networkidle")
    pg.wait_for_function("document.querySelector('#lista .dia, #lista a')", timeout=8000)
    lista, vlista = pg.evaluate("""()=>{document.querySelectorAll('#lista .cd').forEach(e=>{e.textContent='';});
      return [document.getElementById('lista').innerHTML, document.getElementById('vlista').innerHTML];}""")
    extra = pg.evaluate("""()=>['prox','palpite'].map(i=>document.getElementById(i).outerHTML)""")
    b.close()
srv.shutdown()
assert "Carregando" not in lista and "Não deu para carregar" not in lista, "pré-render não montou os bolões"
open(dest, "w", encoding="utf-8").write(montar(lista, vlista, extra))
print(dest, os.path.getsize(dest), "bytes ·", lista.count('class="bl'), "bolões no HTML ·", vlista.count('class="bl'), "da Virada")

if modo == "final":
    hoje = datetime.date.today().isoformat()
    open(REPO + "/sitemap.xml", "w", encoding="utf-8").write(
        '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        f'  <url><loc>https://loterias24horas.com.br/</loc><lastmod>{hoje}</lastmod><changefreq>daily</changefreq></url>\n</urlset>\n')
    open(REPO + "/robots.txt", "w", encoding="utf-8").write(
        "User-agent: *\nAllow: /\nDisallow: /fonte/\n\nSitemap: https://loterias24horas.com.br/sitemap.xml\n")
    # a prévia vira só um atalho para o site oficial
    os.makedirs(REPO + "/novo", exist_ok=True)
    for f in ("dados.json", "avenida.mp3"):
        if os.path.exists(REPO + "/novo/" + f): os.remove(REPO + "/novo/" + f)
    open(REPO + "/novo/index.html", "w", encoding="utf-8").write(
        '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Loterias 24 Horas</title>'
        '<meta name="robots" content="noindex"><link rel="canonical" href="https://loterias24horas.com.br/">'
        '<meta http-equiv="refresh" content="0; url=/"><script>location.replace("/"+location.hash)</script></head>'
        '<body><a href="/">Ir para o Loterias 24 Horas</a></body></html>\n')
    open(REPO + "/README.md", "w", encoding="utf-8").write("""# Loterias 24 Horas

Site dos bolões da Lotérica da Avenida (Vilela & Granhani), Pirassununga/SP: https://loterias24horas.com.br

## Atualizar os bolões

Tudo fica no `dados.json`:

- `boloes`: um item por bolão: `lot` (mega, quina, loteca, milionaria, dupla, timemania, lotofacil), `concurso`, `quando` (sorteio, ou fim das apostas na Loteca, com `-03:00`), `premio`, `formato`, `cotas` (total), `restam`, `valor` (cota no balcão) e, se houver, `app` (cota no app da Caixa), `nome`, `selo`, `link`.
- `virada.boloes`: os bolões da Mega da Virada.
- `palpites`: o palpite do dia do salsicha (data `AAAA-MM-DD` com as 6 dezenas). Troca sozinho à meia-noite; a mesma lista está na planilha, aba "Palpite do Salsicha". Para gerar mais dias: `l24_palpites.py` (não muda os que já existem).

O bolão some sozinho 15 minutos antes de `quando`. As cotas só mudam com o print oficial da Caixa.

O `index.html` é montado por script e já traz os bolões escritos (melhor para o Google). Se só o `dados.json` mudar, o site continua certo: o navegador relê o arquivo ao abrir.
""")
    print("sitemap.xml, robots.txt, README e atalho /novo prontos")
