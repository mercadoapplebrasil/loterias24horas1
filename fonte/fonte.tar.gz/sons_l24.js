document.addEventListener("click",function(e){ if(!window.SOM) return; var t=e.target;
  var s=t.closest&&t.closest("details.dia>summary"); if(s){ s.parentNode.open?SOM.fecha():SOM.abre(); return; }
  if(t.closest&&t.closest("#sx")) return;
  if(t.closest&&t.closest(".ba a,.ba button,.btn,.psh,#prox,.av button.fx,.av a")) SOM.plim(); },true);
