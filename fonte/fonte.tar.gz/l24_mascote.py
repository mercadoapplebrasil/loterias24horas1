# Mascote salsicha com a plaquinha grande da Mega-Sena.
# Show (7,6 s): plaquinha cresce, números acendem e piscam, carimbo PREMIADO!,
# balão "PREMIADO! / AU AU 🐕 AUUU!". Os tempos batem com o l24_som.py.
import math

T = 7.6
def P(t): return f"{max(0.0, min(100.0, t / T * 100)):.2f}%"
def kf(nome, quadros): return "@keyframes %s{%s}" % (nome, "".join(f"{P(t)}{{{c}}}" for t, c in quadros))

css = []
# ---- parado: andando, rabo, plaquinha balançando, dica pulsando ----
css.append("""
.sx text{font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;font-weight:900}
.sx .emo{font-family:"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",system-ui,sans-serif;font-weight:400}
.sx-lg,.sx-rabo,.sx-bola,.sx-carimbo,.sx-e{transform-box:fill-box}
.sx-lg{transform-origin:50% 0}
.sx-a{animation:sx-pa .6s ease-in-out infinite}
.sx-b{animation:sx-pa .6s ease-in-out infinite reverse}
.sx-rabo{transform-origin:100% 100%;animation:sx-rabo .5s ease-in-out infinite alternate}
.sx-corpo{animation:sx-bob .3s ease-in-out infinite alternate}
.sx-sway{transform-origin:0 0;animation:sx-sway 1.6s ease-in-out infinite alternate}
.sx-pop{transform-origin:0 0}
.sx-cab{transform-origin:440px 110px}
.sx-bola,.sx-carimbo,.sx-e{transform-origin:50% 50%}
.sx-carimbo,.sx-e,.sx-fala,.sx-feliz{opacity:0}
.sx-l2a,.sx-l2b{fill-opacity:0}
.sx-fala{transform-origin:448px 46px}
.sx-dica{transform-origin:448px 46px;animation:sx-dica 1.5s ease-in-out infinite alternate}
@keyframes sx-pa{0%,100%{transform:rotate(14deg)}50%{transform:rotate(-14deg)}}
@keyframes sx-rabo{from{transform:rotate(-10deg)}to{transform:rotate(12deg)}}
@keyframes sx-bob{from{transform:translateY(0)}to{transform:translateY(-3px)}}
@keyframes sx-sway{from{transform:rotate(-1.6deg)}to{transform:rotate(1.6deg)}}
@keyframes sx-dica{from{transform:scale(1)}to{transform:scale(1.06)}}
""")

# ---- show ----
regras = []
def anima(sel, nome, quadros, fn="linear"):
    css.append(kf(nome, quadros))
    regras.append(f".sx.show {sel}{{animation:{nome} {T}s {fn} both}}")

anima(".sx-pop", "sx-pop", [(0, "transform:scale(1)"), (.26, "transform:scale(1.13)"), (.40, "transform:scale(1.08)"),
                            (7.15, "transform:scale(1.08)"), (7.6, "transform:scale(1)")])
U, L = "fill:#E3F3E6;stroke:#0E7A3E", "fill:#F5C842;stroke:#C99A12"
for k in range(6):
    tk = .55 + .30 * k
    anima(f".sx-b{k} circle", f"sx-c{k}", [(0, U), (tk - .01, U), (tk + .05, L), (7.15, L), (7.4, U), (7.6, U)])
    anima(f".sx-b{k}", f"sx-s{k}", [(0, "transform:scale(1)"), (tk - .01, "transform:scale(1)"), (tk + .09, "transform:scale(1.32)"),
                                    (tk + .22, "transform:scale(.95)"), (tk + .30, "transform:scale(1)"), (7.6, "transform:scale(1)")])
pisca = [(0, "opacity:1"), (2.33, "opacity:1")]
for t0 in (2.33, 2.58, 2.83):                      # 3 piscadas fortes antes do carimbo
    pisca += [(t0 + .12, "opacity:.15"), (t0 + .25, "opacity:1")]
t = 3.30
while t < 6.9:                                     # e seguem piscando na comemoração
    pisca += [(t + .2, "opacity:.4"), (t + .4, "opacity:1")]; t += .4
pisca += [(7.6, "opacity:1")]
anima(".sx-bolas", "sx-pisca", pisca)
anima(".sx-carimbo", "sx-carimbo", [(0, "opacity:0;transform:scale(2.4)"), (3.17, "opacity:0;transform:scale(2.4)"),
                                    (3.30, "opacity:1;transform:scale(.92)"), (3.40, "opacity:1;transform:scale(1.04)"),
                                    (3.48, "opacity:1;transform:scale(1)"), (7.15, "opacity:1;transform:scale(1)"),
                                    (7.45, "opacity:0;transform:scale(1)"), (7.6, "opacity:0;transform:scale(1)")])
for i in range(5):
    ti = 3.30 + .08 * i
    q = [(0, "opacity:0;transform:scale(0) rotate(0deg)"), (ti, "opacity:0;transform:scale(0) rotate(0deg)"),
         (ti + .12, "opacity:1;transform:scale(1.35) rotate(40deg)"), (ti + .26, "opacity:1;transform:scale(1) rotate(72deg)")]
    t = ti + .26; liga = False
    while t + .25 < 7.1:
        t += .25
        q.append((t, "opacity:1;transform:scale(1) rotate(72deg)" if liga else "opacity:.45;transform:scale(.8) rotate(72deg)")); liga = not liga
    q += [(7.35, "opacity:0;transform:scale(0) rotate(72deg)"), (7.6, "opacity:0;transform:scale(0) rotate(72deg)")]
    anima(f".sx-e{i}", f"sx-e{i}", q)
S1, S0 = "opacity:1;transform:scale(1)", "opacity:0;transform:scale(0)"
anima(".sx-fala", "sx-fala", [(0, S0), (3.28, S0), (3.42, "opacity:1;transform:scale(1.08)"), (3.52, S1),
                              (4.30, S1), (4.36, "opacity:1;transform:scale(1.06)"), (4.46, S1),
                              (4.62, S1), (4.68, "opacity:1;transform:scale(1.06)"), (4.78, S1),
                              (5.00, S1), (5.15, "opacity:1;transform:scale(1.07)"), (5.32, S1),
                              (7.15, S1), (7.40, "opacity:0;transform:scale(.6)"), (7.6, S0)])
anima(".sx-l2a", "sx-l2a", [(0, "fill-opacity:0"), (4.27, "fill-opacity:0"), (4.31, "fill-opacity:1"), (7.6, "fill-opacity:1")])
anima(".sx-l2b", "sx-l2b", [(0, "fill-opacity:0"), (4.97, "fill-opacity:0"), (5.01, "fill-opacity:1"), (7.6, "fill-opacity:1")])
R0 = "transform:rotate(0deg)"
anima(".sx-cab", "sx-cab", [(0, R0), (4.28, R0), (4.34, "transform:rotate(3.5deg)"), (4.46, R0), (4.60, R0),
                            (4.66, "transform:rotate(3.5deg)"), (4.80, R0), (4.95, R0), (5.25, "transform:rotate(-4deg)"),
                            (6.20, "transform:rotate(-4deg)"), (6.45, R0), (7.6, R0)], "ease-in-out")
anima(".sx-olho", "sx-olho", [(0, "opacity:1"), (3.28, "opacity:1"), (3.32, "opacity:0"), (7.15, "opacity:0"), (7.2, "opacity:1"), (7.6, "opacity:1")])
anima(".sx-feliz", "sx-feliz", [(0, "opacity:0"), (3.28, "opacity:0"), (3.32, "opacity:1"), (7.15, "opacity:1"), (7.2, "opacity:0"), (7.6, "opacity:0")])
anima(".sx-dica", "sx-dicaoff", [(0, "opacity:1;transform:scale(1)"), (.2, "opacity:0;transform:scale(.8)"),
                                 (7.35, "opacity:0;transform:scale(.8)"), (7.6, "opacity:1;transform:scale(1)")])
regras.append(".sx.show .sx-rabo{animation-duration:.16s}")
css += regras
css.append("""@media (prefers-reduced-motion:reduce){
.sx.show .sx-dica{opacity:0}.sx.show .sx-fala{opacity:1;transform:none}
.sx.show .sx-l2a,.sx.show .sx-l2b{fill-opacity:1}.sx.show .sx-carimbo,.sx.show .sx-e{opacity:1;transform:none}
.sx.show .sx-bola circle{fill:#F5C842;stroke:#C99A12}.sx.show .sx-olho{opacity:0}.sx.show .sx-feliz{opacity:1}}""")

# ---- desenho ----
def estrela(R=24, r=10):
    pts = []
    for k in range(10):
        a = math.radians(-90 + 36 * k); rr = R if k % 2 == 0 else r
        pts.append(f"{rr * math.cos(a):.1f} {rr * math.sin(a):.1f}")
    return "M" + "L".join(pts) + "Z"

def balao(x0, y0, x1, y1, r, cauda):
    (ta, (px, py), tb) = cauda
    return (f"M{x0 + r} {y0}H{x1 - r}A{r} {r} 0 0 1 {x1} {y0 + r}V{y1 - r}A{r} {r} 0 0 1 {x1 - r} {y1}"
            f"H{ta}L{px} {py}L{tb} {y1}H{x0 + r}A{r} {r} 0 0 1 {x0} {y1 - r}V{y0 + r}A{r} {r} 0 0 1 {x0 + r} {y0}Z")

W, H = 450, 320
BOLAS = [(85, 120), (225, 120), (365, 120), (85, 204), (225, 204), (365, 204)]
NUMS = ["07", "13", "24", "33", "41", "58"]
ESTRELAS = [(430, 20), (452, 196), (20, 304), (300, -6), (128, -8)]
bolas = "".join(
    f'<g class="sx-bola sx-b{k}"><circle cx="{x}" cy="{y}" r="37" fill="#E3F3E6" stroke="#0E7A3E" stroke-width="5"/>'
    f'<text x="{x}" y="{y + 13}" font-size="38" text-anchor="middle" fill="#0B3D24">{n}</text></g>'
    for k, ((x, y), n) in enumerate(zip(BOLAS, NUMS)))
estrelas = "".join(
    f'<g transform="translate({x} {y})"><path class="sx-e sx-e{i}" d="{estrela()}" fill="#F5C842" stroke="#C99A12" stroke-width="3" stroke-linejoin="round"/></g>'
    for i, (x, y) in enumerate(ESTRELAS))
bilhete = f'''<g transform="translate(515 104) rotate(-5)"><g class="sx-sway"><g class="sx-pop"><g transform="translate(0 -{H // 2})">
<rect width="{W}" height="{H}" rx="24" fill="#fff"/>
<path d="M24 0H{W - 24}A24 24 0 0 1 {W} 24V74H0V24A24 24 0 0 1 24 0Z" fill="#0E7A3E"/>
<text x="{W // 2}" y="55" font-size="48" text-anchor="middle" fill="#fff" letter-spacing="1">MEGA-SENA</text>
<rect width="{W}" height="{H}" rx="24" fill="none" stroke="#0B5F31" stroke-width="8"/>
<g class="sx-bolas">{bolas}</g>
<text class="sx-pd" x="{W // 2}" y="292" font-size="28" text-anchor="middle" fill="#0E7A3E" letter-spacing="1">PALPITE DO DIA</text>
<g transform="translate(225 292) rotate(-4)"><g class="sx-carimbo"><rect x="-175" y="-40" width="350" height="80" rx="18" fill="#F5C842" stroke="#0B3D24" stroke-width="6"/>
<text y="17" font-size="50" text-anchor="middle" fill="#0B3D24">PREMIADO!</text></g></g>
{estrelas}
</g></g></g></g>'''

cachorro = f'''<ellipse cx="300" cy="282" rx="260" ry="10" fill="#C9E6D0"/>
<g class="sx-corpo">
<path class="sx-rabo" d="M74 150c-30-10-44-40-40-70" fill="none" stroke="#6B3A1C" stroke-width="16" stroke-linecap="round"/>
<g class="sx-lg sx-a"><rect x="104" y="196" width="26" height="70" rx="12" fill="#5A2F16"/><ellipse cx="117" cy="264" rx="18" ry="8" fill="#A8692F"/></g>
<g class="sx-lg sx-b"><rect x="356" y="196" width="26" height="70" rx="12" fill="#5A2F16"/><ellipse cx="369" cy="264" rx="18" ry="8" fill="#A8692F"/></g>
<rect x="64" y="118" width="350" height="100" rx="50" fill="#7A4422"/>
<path d="M110 206c80 16 200 16 280 0v8c-80 18-200 18-280 0z" fill="#C8843F"/>
<g class="sx-lg sx-b"><rect x="128" y="196" width="28" height="74" rx="13" fill="#7A4422"/><ellipse cx="142" cy="268" rx="22" ry="10" fill="#C8843F"/></g>
<g class="sx-lg sx-a"><rect x="380" y="196" width="28" height="74" rx="13" fill="#7A4422"/><ellipse cx="394" cy="268" rx="22" ry="10" fill="#C8843F"/></g>
<path d="M370 150c10-40 40-62 70-62l20 60c-30 10-56 34-70 66z" fill="#7A4422"/>
<path d="M378 150c26-22 54-30 86-26l6 22c-34-2-62 8-84 28z" fill="#0E7A3E"/>
<path d="M420 136l14 46 22-42c-12-4-24-6-36-4z" fill="#0B5F31"/>
<circle cx="436" cy="176" r="15" fill="#F5C842" stroke="#C99A12" stroke-width="3"/>
<text x="436" y="182" font-size="15" text-anchor="middle" fill="#0B3D24">24</text>
<g class="sx-cab">
{bilhete}
<ellipse cx="456" cy="84" rx="48" ry="42" fill="#7A4422"/>
<path d="M478 58c30 4 58 18 70 34 4 6 0 14-8 16-26 6-52 8-78 2z" fill="#7A4422"/>
<path d="M480 96c22 6 44 6 62 2-14 12-38 16-62 8z" fill="#C8843F"/>
<circle cx="546" cy="88" r="11" fill="#2B1A0E"/>
<path d="M430 60c-24 4-34 40-26 80 4 18 22 22 32 8 10-20 12-56 6-80z" fill="#9A5A2C"/>
<g class="sx-olho"><ellipse cx="478" cy="72" rx="8" ry="9" fill="#2B1A0E"/><circle cx="481" cy="69" r="3" fill="#fff"/></g>
<path class="sx-feliz" d="M469 76q9-13 18 0" fill="none" stroke="#2B1A0E" stroke-width="5" stroke-linecap="round"/>
<path d="M468 56c8-6 18-6 24 0" fill="none" stroke="#C8843F" stroke-width="5" stroke-linecap="round"/>
<path d="M486 104c10 5 22 6 34 4" fill="none" stroke="#5A2F16" stroke-width="7" stroke-linecap="round"/>
</g>
</g>'''

PONTA = (448, 46)
dica = (f'<g class="sx-dica"><path d="{balao(150, -44, 440, 28, 36, (400, PONTA, 368))}" fill="#fff" stroke="#0B3D24" stroke-width="5" stroke-linejoin="round"/>'
        f'<text x="292" y="5" font-size="34" text-anchor="middle" fill="#0B3D24"><tspan class="sx-dt">Toque aqui!</tspan> <tspan class="emo">🔊</tspan></text></g>')
fala = (f'<g class="sx-fala"><path d="{balao(12, -150, 446, 22, 40, (404, PONTA, 356))}" fill="#fff" stroke="#0B3D24" stroke-width="6" stroke-linejoin="round"/>'
        f'<text x="229" y="-78" font-size="58" text-anchor="middle" fill="#0E7A3E">PREMIADO!</text>'
        f'<text x="229" y="-14" font-size="44" text-anchor="middle" fill="#7A4422"><tspan class="sx-l2a">AU AU <tspan class="emo">🐕</tspan></tspan><tspan class="sx-l2b"> AUUU!</tspan></text></g>')

# ---- caixa de visão: inclui a plaquinha em todas as posições do show ----
def pontos():
    base = [(0, 0), (W, 0), (0, H), (W, H), (225 - 180, 292 - 52), (225 + 180, 292 + 52), (225 + 180, 292 - 52), (225 - 180, 292 + 52)]
    base += [(x + dx, y + dy) for (x, y) in ESTRELAS for dx in (-33, 33) for dy in (-33, 33)]
    return [(x, y - H / 2) for (x, y) in base]
def rot(p, a, c=(0, 0)):
    a = math.radians(a); x, y = p[0] - c[0], p[1] - c[1]
    return (c[0] + x * math.cos(a) - y * math.sin(a), c[1] + x * math.sin(a) + y * math.cos(a))
xs, ys = [12, 26, 452, 40, 560], [-153, 292]
for s, cab in [(1, 0), (1.13, 0), (1.08, 3.5), (1.08, -4)]:
    for sw in (-1.6, 1.6):
        for (x, y) in pontos():
            q = rot((x * s, y * s), sw); q = rot(q, -5); q = (q[0] + 515, q[1] + 104); q = rot(q, cab, (440, 110))
            xs.append(q[0]); ys.append(q[1] - 3)
x0, y0 = math.floor(min(xs)) - 6, math.floor(min(ys)) - 6
x1, y1 = math.ceil(max(xs)) + 6, 296
vb = f"{x0} {y0} {x1 - x0} {y1 - y0}"
svg = (f'<svg class="sx" viewBox="{vb}" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">'
       f'<style>{"".join(css)}</style>{cachorro}{dica}{fala}</svg>')
open("/home/claude/scripts/l24_mascote.svg", "w", encoding="utf-8").write(svg)
print("viewBox", vb, "·", len(svg), "bytes")
