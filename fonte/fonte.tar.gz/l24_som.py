# Som do mascote: plim nos números, fanfarra no PREMIADO e "au au auuu".
# A linha do tempo bate com a animação (mesmos segundos do l24_mascote.py).
import sys, subprocess, numpy as np, scipy.signal as ss, wave

SR = 44100
DUR = 7.4
N = int(SR * DUR)
rng = np.random.default_rng(24)
mix = np.zeros(N)

def poe(sig, t0, ganho):
    i = int(round(t0 * SR)); j = min(N, i + len(sig))
    mix[i:j] += ganho * sig[: j - i]

def norm(x):
    m = np.max(np.abs(x)); return x / m if m > 0 else x

def banda(x, lo, hi, ordem=2):
    b, a = ss.butter(ordem, [lo / (SR / 2), hi / (SR / 2)], "band"); return ss.lfilter(b, a, x)

def ruido_suave(n, corte=12.0):
    b, a = ss.butter(2, corte / (SR / 2)); return norm(ss.lfilter(b, a, rng.standard_normal(n)))

def ressonador(x, F, B):
    """Ressonador de 2 polos (Klatt) com frequência e banda variando no tempo."""
    C = -np.exp(-2 * np.pi * B / SR)
    Bc = 2 * np.exp(-np.pi * B / SR) * np.cos(2 * np.pi * F / SR)
    A = 1 - Bc - C
    y = np.zeros_like(x); y1 = y2 = 0.0
    for i in range(len(x)):
        yi = A[i] * x[i] + Bc[i] * y1 + C[i] * y2
        y[i] = yi; y2 = y1; y1 = yi
    return y

def fonte(f0, rolloff, teto=7000.0):
    ph = 2 * np.pi * np.cumsum(f0) / SR
    s = np.zeros(len(f0))
    for k in range(1, 30):
        s += (k * f0 < teto) * np.sin(k * ph) / k ** rolloff
    return s, ph

# ---------- efeitos ----------
def bloop():                                    # plaquinha crescendo
    d = 0.24; n = int(d * SR); t = np.arange(n) / SR
    f = 240 * (900 / 240) ** (t / d)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return (np.sin(ph) + 0.2 * np.sin(2 * ph)) * np.minimum(1, t / 0.01) * np.exp(-t / 0.1)

def sino(f, d=0.7, tau=0.24):                   # "plim" de cada número
    n = int(d * SR); t = np.arange(n) / SR; s = np.zeros(n)
    for m, a, tt in [(1, 1, tau), (2.0, .42, tau * .55), (3.01, .16, tau * .4), (4.17, .08, tau * .3), (5.43, .04, tau * .25)]:
        if f * m < 16000: s += a * np.sin(2 * np.pi * f * m * t) * np.exp(-t / tt)
    return s * np.minimum(1, t / 0.003)

def tum():                                      # carimbo batendo
    d = 0.3; n = int(d * SR); t = np.arange(n) / SR
    f = 100 * np.exp(-t / 0.1) + 48
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.08)
    clique = banda(rng.standard_normal(n), 300, 3500) * np.exp(-t / 0.008)
    return norm(s) + 0.35 * norm(clique)

def metal(f, d, vib=0.0):                       # nota de fanfarra
    n = int(d * SR); t = np.arange(n) / SR
    fv = f * (1 + vib * np.sin(2 * np.pi * 5.5 * t) * np.clip((t - .12) / .2, 0, 1))
    s, _ = fonte(fv, 1.0, teto=min(9000, f * 9))
    b, a = ss.butter(2, min(.95, f * 5 / (SR / 2))); s = ss.lfilter(b, a, s)
    e = np.minimum(1, t / 0.015) * (0.85 + 0.15 * np.exp(-t / 0.05)) * np.clip((d - t) / 0.09, 0, 1)
    return norm(s) * e

def latido(d=0.21, fi=420, fp=640, ff=360, tp=0.035, sobe=1.0):
    n = int(d * SR); t = np.arange(n) / SR
    f0 = np.where(t < tp, fi + (fp - fi) * np.clip(t / tp, 0, 1) ** .7, fp + (ff - fp) * np.clip((t - tp) / (d - tp), 0, 1) ** .8) * sobe
    f0 = f0 * (1 + 0.03 * ruido_suave(n, 60))
    s, ph = fonte(f0, 1.1)
    s = norm(s) + 0.45 * np.sin(0.5 * ph) * np.exp(-t / 0.07)          # aspereza (sub-harmônico)
    s = norm(s) + 0.5 * norm(banda(rng.standard_normal(n), 900, 6500))  # sopro
    u = np.clip(t / d, 0, 1) ** 1.2                                      # "a" -> "u"
    y = ressonador(s, 860 - 330 * u, np.full(n, 140.0))
    y = ressonador(y, 1650 - 550 * u, np.full(n, 170.0))
    y = ressonador(y, 2850 - 250 * u, np.full(n, 250.0))
    y = ressonador(y, np.full(n, 3900.0), np.full(n, 330.0))
    e = np.where(t < .008, (t / .008) ** 1.5, np.where(t < .055, 1 - (t - .008) * 4, (1 - .047 * 4) * np.exp(-(t - .055) / .05)))
    y = norm(y) * e * np.clip((d - t) / .02, 0, 1)
    estalo = banda(rng.standard_normal(n), 500, 5000) * np.exp(-t / .004)
    y = y + .3 * norm(estalo)
    return np.tanh(2.2 * y) / np.tanh(2.2)

def uivo(d=1.4):
    n = int(d * SR); t = np.arange(n) / SR
    f0 = np.interp(t, [0, .10, .45, .95, 1.12, d], [520, 565, 775, 800, 720, 560])
    vib = 1 + .02 * np.sin(2 * np.pi * 5.3 * t) * np.clip((t - .35) / .2, 0, 1) * np.clip((d - .12 - t) / .2, 0, 1)
    f0 = f0 * vib * (1 + .006 * ruido_suave(n, 8))
    s, _ = fonte(f0, 1.65)
    s = norm(s) + .07 * norm(banda(rng.standard_normal(n), 800, 5000))
    F1 = np.interp(t, [0, .25, d], [820, 440, 420]); F2 = np.interp(t, [0, .25, d], [1500, 920, 860])
    y = ressonador(s, F1, np.full(n, 110.0))
    y = ressonador(y, F2, np.full(n, 140.0))
    y = ressonador(y, np.interp(t, [0, .25, d], [2750, 2550, 2500]), np.full(n, 220.0))
    y = ressonador(y, np.full(n, 3800.0), np.full(n, 300.0))
    ataque = np.where(t < .12, .5 - .5 * np.cos(np.pi * t / .12), 1)
    solta = np.where(t > d - .4, .5 + .5 * np.cos(np.pi * (t - (d - .4)) / .4), 1)
    trem = 1 + .07 * np.sin(2 * np.pi * 5.3 * t + .8)
    y = norm(y) * ataque * solta * trem
    return np.tanh(1.4 * y) / np.tanh(1.4)

def reverb(x, rt=0.55, mol=0.16):
    n = int(rt * SR); t = np.arange(n) / SR
    ir = rng.standard_normal(n) * np.exp(-t / (rt / 6.9))
    b, a = ss.butter(1, 4500 / (SR / 2)); ir = ss.lfilter(b, a, ir)
    ir[: int(.015 * SR)] = 0; ir /= np.sqrt(np.sum(ir ** 2))
    w = ss.fftconvolve(x, ir)[: len(x)]
    return x + mol * norm(w) * np.max(np.abs(x))

# ---------- linha do tempo (segundos) ----------
poe(bloop(), 0.02, .22)
notas = [1046.5, 1174.7, 1318.5, 1568.0, 1760.0, 2093.0]
for k, f in enumerate(notas):
    poe(sino(f), 0.55 + 0.30 * k, .26)
for k, t0 in enumerate([2.40, 2.65, 2.90]):
    poe(sino(2637.0, d=.3, tau=.07) + .6 * sino(3136.0, d=.3, tau=.06), t0, .14)
poe(tum(), 3.20, .42)
for f, t0 in [(392.0, 3.24), (523.25, 3.36), (659.26, 3.48)]:
    poe(metal(f, .14), t0, .16)
for f, v in [(523.25, 0), (659.26, 0), (783.99, 0), (1046.5, .006)]:
    poe(metal(f, .62, vib=v), 3.60, .12)
poe(latido(), 4.30, .62)
poe(latido(d=.19, fi=440, fp=670, ff=380, sobe=1.04), 4.62, .62)
poe(uivo(), 5.00, .55)

mix = reverb(mix)
mix *= np.clip(np.arange(N) / (0.005 * SR), 0, 1)
mix = 0.89 * mix / np.max(np.abs(mix))
pcm = (mix * 32767).astype("<i2")
wav = sys.argv[1] if len(sys.argv) > 1 else "/tmp/auau.wav"
with wave.open(wav, "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
print("ok", wav, round(DUR, 2), "s")
